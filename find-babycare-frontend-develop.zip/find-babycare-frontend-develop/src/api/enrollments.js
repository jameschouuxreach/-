import data from './mocks/enrollments.json';

// @see https://airtable.com/appfYDsNIRoD3ar7z/tbluSf2K9duCtoUZQ/viwtSsTsHUf1ViNFu?blocks=show
export const enrollments = data.records;
