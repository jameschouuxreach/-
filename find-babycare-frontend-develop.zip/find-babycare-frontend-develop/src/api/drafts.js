import data from './mocks/drafts.json';

// @see https://airtable.com/appfYDsNIRoD3ar7z/tbluSf2K9duCtoUZQ/viwtSsTsHUf1ViNFu?blocks=show
export const drafts = data.records;
