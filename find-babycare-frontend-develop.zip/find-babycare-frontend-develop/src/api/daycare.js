import data from './mocks/daycares.json';

// TODO: airtable API
// @see npm package:   https://www.npmjs.com/package/airtable
// @see create tokens: https://airtable.com/create/tokens

export const daycares = data.records;
