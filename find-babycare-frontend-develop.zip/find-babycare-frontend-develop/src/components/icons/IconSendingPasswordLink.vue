<template>
  <svg width="244" height="82" viewBox="0 0 244 82" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g id="sanding password link">
  <g id="Layer 1">
  <path id="Vector" d="M85.8567 0.512695H187.399C188.984 0.512695 190.505 1.1393 191.627 2.25466C192.748 3.37001 193.378 4.88276 193.378 6.46012V67.6987C193.378 69.2761 192.748 70.7888 191.627 71.9042C190.505 73.0195 188.984 73.6461 187.399 73.6461H79.5721C78.7864 73.6469 78.0082 73.4936 77.2821 73.1951C76.556 72.8966 75.8961 72.4586 75.3403 71.9062C74.7844 71.3539 74.3435 70.698 74.0426 69.976C73.7418 69.2541 73.5869 68.4802 73.5869 67.6987V12.7172C73.5869 9.48035 74.8796 6.37609 77.1807 4.08731C79.4817 1.79852 82.6026 0.512695 85.8567 0.512695Z" fill="#EA580C"/>
  <path id="Vector_2" d="M194.253 7.37146H86.4207C83.1184 7.37146 80.4414 10.0342 80.4414 13.3189V74.54C80.4414 77.8246 83.1184 80.4874 86.4207 80.4874H194.253C197.555 80.4874 200.232 77.8246 200.232 74.54V13.3189C200.232 10.0342 197.555 7.37146 194.253 7.37146Z" stroke="#111827" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_3" d="M80.7114 18.9042L133.573 52.8652C135.398 54.0197 137.516 54.6329 139.679 54.6329C141.842 54.6329 143.959 54.0197 145.784 52.8652L199.093 18.9334" stroke="#111827" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_4" d="M63.0026 30.2556H2" stroke="#111827" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_5" d="M63.0026 40.0707H2" stroke="#111827" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_6" d="M63.0026 49.8856H2" stroke="#111827" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  </g>
  <g id="Group 6">
  <g id="Group 1">
  <line id="Line 1" x1="138.522" y1="74.7842" x2="147.022" y2="60.0618" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 2" x1="139.12" y1="60.062" x2="147.62" y2="74.7844" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 3" x1="135.5" y1="67.6021" x2="150.5" y2="67.6021" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  </g>
  <g id="Group 2">
  <line id="Line 1_2" x1="161.522" y1="74.7842" x2="170.022" y2="60.0618" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 2_2" x1="162.12" y1="60.062" x2="170.62" y2="74.7844" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 3_2" x1="158.5" y1="67.6021" x2="173.5" y2="67.6021" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  </g>
  <g id="Group 3">
  <line id="Line 1_3" x1="184.522" y1="74.7842" x2="193.022" y2="60.0618" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 2_3" x1="185.12" y1="60.062" x2="193.62" y2="74.7844" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 3_3" x1="181.5" y1="67.6021" x2="196.5" y2="67.6021" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  </g>
  <g id="Group 4">
  <line id="Line 1_4" x1="207.522" y1="74.7842" x2="216.022" y2="60.0618" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 2_4" x1="208.12" y1="60.062" x2="216.62" y2="74.7844" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 3_4" x1="204.5" y1="67.6021" x2="219.5" y2="67.6021" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  </g>
  <g id="Group 5">
  <line id="Line 1_5" x1="230.522" y1="74.7842" x2="239.022" y2="60.0618" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 2_5" x1="231.12" y1="60.062" x2="239.62" y2="74.7844" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  <line id="Line 3_5" x1="227.5" y1="67.6021" x2="242.5" y2="67.6021" stroke="#111827" stroke-width="3" stroke-linecap="round"/>
  </g>
  </g>
  </g>
  </svg>
</template>
