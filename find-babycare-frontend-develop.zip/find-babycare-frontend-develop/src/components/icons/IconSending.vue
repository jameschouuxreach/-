<template>
  <svg width="200" height="82" viewBox="0 0 200 82" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g id="Sending 1" clip-path="url(#clip0_5262_11468)">
  <g id="Layer 2">
  <g id="Layer 1">
  <path id="Vector" d="M84.7376 0.574463H186.279C187.865 0.574463 189.386 1.20106 190.507 2.31642C191.629 3.43178 192.259 4.94453 192.259 6.52189V67.7605C192.259 69.3378 191.629 70.8506 190.507 71.9659C189.386 73.0813 187.865 73.7079 186.279 73.7079H78.4529C77.6672 73.7087 76.8891 73.5554 76.1629 73.2569C75.4368 72.9583 74.777 72.5204 74.2211 71.968C73.6653 71.4157 73.2243 70.7598 72.9235 70.0378C72.6226 69.3159 72.4678 68.542 72.4678 67.7605V12.7789C72.4678 9.54212 73.7605 6.43786 76.0615 4.14907C78.3626 1.86029 81.4834 0.574463 84.7376 0.574463Z" fill="#E85924"/>
  <path id="Vector_2" d="M193.134 7.43323H85.3015C81.9993 7.43323 79.3223 10.096 79.3223 13.3807V74.6017C79.3223 77.8864 81.9993 80.5491 85.3015 80.5491H193.134C196.436 80.5491 199.113 77.8864 199.113 74.6017V13.3807C199.113 10.096 196.436 7.43323 193.134 7.43323Z" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_3" d="M79.5923 18.9659L132.454 52.927C134.279 54.0815 136.397 54.6946 138.56 54.6946C140.722 54.6946 142.84 54.0815 144.665 52.927L197.974 18.9952" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_4" d="M61.8835 30.3174H0.880859" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_5" d="M61.8835 40.1324H0.880859" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  <path id="Vector_6" d="M61.8835 49.9474H0.880859" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round"/>
  </g>
  </g>
  </g>
  <defs>
  <clipPath id="clip0_5262_11468">
  <rect width="200" height="80.8511" fill="white" transform="translate(0 0.574463)"/>
  </clipPath>
  </defs>
  </svg>
</template>
