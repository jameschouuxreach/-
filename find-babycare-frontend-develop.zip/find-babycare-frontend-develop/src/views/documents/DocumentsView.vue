<template>
  Documents View
  <RouterView />
</template>
