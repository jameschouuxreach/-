<template>
  Samples View
</template>
