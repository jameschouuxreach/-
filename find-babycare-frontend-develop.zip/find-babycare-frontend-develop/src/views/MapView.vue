<template>
  <div class="relative overflow-hidden">
    <OlMap />
  </div>
</template>

<script setup>
import OlMap from '../components/map/OlMap.vue';
</script>
