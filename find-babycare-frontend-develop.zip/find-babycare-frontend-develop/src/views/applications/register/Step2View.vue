<template>
  Step2 View
</template>
